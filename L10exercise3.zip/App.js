import { setStatusBarBackgroundColor, StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View,Image, FlatList, TouchableOpacity, SectionList } from 'react-native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';

const datasource = [
{
    
  title: "Water",
  bgcolor: 'skyblue',
  icon:"water",
  data: [
      {name: "Poliwrath",
        img: "https://dz3we2x72f7ol.cloudfront.net/expansions/151/en-us/SV3pt5_EN_62-2x.png",
       
      },
      
      {
        name: "Blastoise",
        img: "https://dz3we2x72f7ol.cloudfront.net/expansions/151/en-us/SV3pt5_EN_9-2x.png",
        
      }
    ],
    
    

  },
  {
    title: "Fire",
    bgcolor:'red',
    icon:"fire",
    data: [
      {name: "Charmander",
        img: "https://dz3we2x72f7ol.cloudfront.net/expansions/151/en-us/SV3pt5_EN_6-2x.png"
       },
      
      {
        name: "Arcanine",
        img: "https://dz3we2x72f7ol.cloudfront.net/expansions/151/en-us/SV3pt5_EN_59-2x.png"
      }
    ],
    
  },
  {
    title: "Electric",
    bgcolor:'orange',
    icon:"bolt",
    data: [
      {name: "Pikachu",
        img: "https://dz3we2x72f7ol.cloudfront.net/expansions/151/en-us/SV3pt5_EN_25-2x.png"
       },
      
      {
        name: "Electrode",
        img: "https://dz3we2x72f7ol.cloudfront.net/expansions/151/en-us/SV3pt5_EN_101-2x.png"
      }
    ],
  }

];

const App = () => {

  const renderItem = ({ item }) => {
    return (
      <TouchableOpacity style={styles.row}>
        <Text style={styles.name}>{item.name}</Text>

        <Image 
        source={{uri: item.img}}
        style={styles.card} />

      </TouchableOpacity>
      
  
    );
  };

   return (
    <View style={{ marginTop: 40 }}>
      <TouchableOpacity style={styles.addBtn}>
        <Text style={styles.addText}>ADD POKEMON</Text>
      </TouchableOpacity>


      <SectionList
        sections={datasource}
        renderItem={renderItem}
        keyExtractor={(item, index) => item.name + index}
        renderSectionHeader={({ section }) => (
          <View style={[styles.header, { backgroundColor: section.bgcolor }]}>
            <FontAwesome6 name={section.icon} size={20} color="white" />
            <Text style={styles.headerText}>  {section.title}</Text>
          </View>
        )}
      />

      <StatusBar translucent={false} />
    </View>
  );
};

const styles = StyleSheet.create({
  addBtn: {
    backgroundColor: "dodgerblue",
    padding: 12,
    marginHorizontal: 15,
    borderRadius: 8,
    marginBottom: 10
  },
  addText: {
    color: "white",
    fontSize: 18,
    textAlign: "center",
    fontWeight: "bold"
  },

  header: {
    flexDirection: "row",
    padding: 10,
  },

  headerText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "white",
  },

  row: {
    flexDirection: "row",
    padding: 10,
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderColor: "#ccc"
  },

  name: {
    fontSize: 18,
    flex: 1
  },

  card: {
    width: 100,
    height: 150,
    
  }
});

export default App;

