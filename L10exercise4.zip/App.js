import { setStatusBarBackgroundColor, StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View,Image, FlatList, TouchableOpacity, SectionList } from 'react-native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';

const datasource = [
{
    
  title: "Korean Food",
  bgcolor: 'skyblue',
  icon:"hotjar",
  data: [
      {name: "Kimchi",
        img: "https://th.bing.com/th/id/R.894b32fb1c634f25344e85522fb90d82?rik=CCM5%2bKoLFYOEjQ&riu=http%3a%2f%2fwww.ricenflour.com%2fwp-content%2fuploads%2f2017%2f03%2fVegan-kimchi-recipe.jpg&ehk=oxsWb4XN8Haft4at%2f9W16SkatfBtJGhtkwL4cCaGKcg%3d&risl=&pid=ImgRaw&r=0",
       
      },
      
      {
        name: "Tteokbokki",
        img: "https://tse2.mm.bing.net/th/id/OIP.953pjuisrJHZkHiEmzGshwHaE8?rs=1&pid=ImgDetMain&o=7&rm=3",
        
      }
    ],
    
    

  },
  {
    title: "Chinese Food",
    bgcolor:'red',
    icon:"dragon",
    data: [
      {name: "Dim sum ",
        img: "https://cdn.cnn.com/cnnnext/dam/assets/160325033254-hk-dim-sum-fook-lam-moon.jpg"
       },
      
      {
        name: "Peking Duck",
        img: "https://redhousespice.com/wp-content/uploads/2022/01/sliced-peking-duck-with-pancakes-scaled.jpg"
      }
    ],
    
  },
  {
    title: "Japaness Food",
    bgcolor:'orange',
    icon:"bowl-food",
    data: [
      {name: "Sushi",
        img: "https://tse4.mm.bing.net/th/id/OIP.2BosvglyK7BU5nsmvzXecQHaE8?rs=1&pid=ImgDetMain&o=7&rm=3"
       },
      
      {
        name: "Ramen",
        img: "https://www.wikihow.com/images/6/67/Cook-Basic-Japanese-Ramen-Step-10.jpg"
      }
    ],
  }

];

const App = () => {

  const renderItem = ({ item }) => {
    return (
      <TouchableOpacity style={styles.row}>
        <Text style={styles.name}>{item.name}</Text>

        <Image 
        source={{uri: item.img}}
        style={styles.card} />

      </TouchableOpacity>
      
  
    );
  };

   return (
    <View style={{ marginTop: 40 }}>
      <TouchableOpacity style={styles.addBtn}>
        <Text style={styles.addText}>ADD FOOD</Text>
      </TouchableOpacity>


      <SectionList
        sections={datasource}
        renderItem={renderItem}
        keyExtractor={(item, index) => item.name + index}
        renderSectionHeader={({ section }) => (
          <View style={[styles.header, { backgroundColor: section.bgcolor }]}>
            <FontAwesome6 name={section.icon} size={20} color="white" />
            <Text style={styles.headerText}>  {section.title}</Text>
          </View>
        )}
      />

      <StatusBar translucent={false} />
    </View>
  );
};

const styles = StyleSheet.create({
  addBtn: {
    backgroundColor: "dodgerblue",
    padding: 12,
    marginHorizontal: 15,
    borderRadius: 8,
    marginBottom: 10
  },
  addText: {
    color: "white",
    fontSize: 18,
    textAlign: "center",
    fontWeight: "bold"
  },

  header: {
    flexDirection: "row",
    padding: 10,
  },

  headerText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "white",
  },

  row: {
    flexDirection: "row",
    padding: 10,
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderColor: "#ccc"
  },

  name: {
    fontSize: 18,
    flex: 1
  },

  card: {
    width: 100,
    height: 150,
    
  }
});

export default App;